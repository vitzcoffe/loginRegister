<?php

include 'conexion_be.php';

$nombre_completo = $_POST['nombre_completo'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Seguridad: Evitar inyección SQL
$nombre_completo = mysqli_real_escape_string($conexion, $nombre_completo);
$correo = mysqli_real_escape_string($conexion, $correo);
$usuario = mysqli_real_escape_string($conexion, $usuario);
$contrasena = mysqli_real_escape_string($conexion, $contrasena);

// Encriptar contraseña
$contrasena = password_hash($contrasena, PASSWORD_DEFAULT);

// Verificar si el correo o el usuario ya existen
$verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE usuario='$usuario' OR correo='$correo'");

if (mysqli_num_rows($verificar_usuario) > 0) {
    echo '
    <script>
        alert("Error: El usuario o correo ya están registrados.");
        window.location = "../index.php"; // Redirigir a login-register
    </script>
    ';
    exit(); // Detener la ejecución del script
}

// Si no existen, insertar el nuevo usuario
$query = "INSERT INTO usuarios (nombre_completo, correo, usuario, contrasena) 
          VALUES ('$nombre_completo', '$correo', '$usuario', '$contrasena')";

$ejecutar = mysqli_query($conexion, $query);

if ($ejecutar) {
    echo '
    <script>
        alert("Usuario almacenado correctamente");
        window.location = "../index.php"; // Redirigir a la página principal
    </script>
    ';
} else {
    echo '
    <script>
        alert("Error al registrar el usuario");
        window.location = "../index.php"; // Redirigir a login-register en caso de error
    </script>
    ';
}

?>
